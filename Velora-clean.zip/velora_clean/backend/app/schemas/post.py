from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class PostCreateRequest(BaseModel):
    content: str = Field(..., min_length=1)
    moderation_status: str = Field(..., description='safe, warning, harmful, or critical')
    risk_score: float = Field(..., ge=0, le=100)
    categories: list[str] = Field(default_factory=list)
    image_path: Optional[str] = None
    document_path: Optional[str] = None


class PostResponse(BaseModel):
    id: int
    user_id: int
    content: str
    image_path: Optional[str]
    document_path: Optional[str]
    moderation_status: str
    risk_score: float
    categories: list[str]
    created_at: datetime

    model_config = {
        'from_attributes': True,
    }


class PostFeedResponse(PostResponse):
    username: str
