﻿from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class ScanHistoryResponse(BaseModel):
    id: int = Field(..., description="Scan result ID")
    content_type: str = Field(
        ...,
        description="Type of content: text, image, or document",
        examples=["text"],
    )
    file_name: Optional[str] = Field(
        default=None,
        description="Original file name if uploaded",
        examples=["document.pdf"],
    )
    status: str = Field(
        ...,
        description="Moderation status: safe, warning, harmful, or critical",
        examples=["safe"],
    )
    risk_score: float = Field(
        ...,
        ge=0,
        le=100,
        description="Risk score from 0 to 100",
        examples=[25.5],
    )
    categories: list[str] = Field(
        default_factory=list,
        description="List of detected harmful categories",
        examples=[],
    )
    created_at: datetime = Field(
        ...,
        description="Scan creation timestamp",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "id": 1,
                "content_type": "text",
                "file_name": None,
                "status": "safe",
                "risk_score": 10,
                "categories": [],
                "created_at": "2026-06-24T12:00:00",
            }
        }
    }
