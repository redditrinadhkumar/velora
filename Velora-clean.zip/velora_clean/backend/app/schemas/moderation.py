﻿from __future__ import annotations

from typing import Optional
from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class ModerationRequest(BaseModel):
    text: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=10000,
        description="Text content to moderate",
        examples=["This is a test content for moderation"],
    )

    @field_validator("text")
    @classmethod
    def text_not_empty_if_provided(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v.strip() == "":
            raise ValueError("Text cannot be empty or whitespace only")
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "text": "Sample content for moderation analysis"
            }
        }
    }


class ModerationResponse(BaseModel):
    status: str = Field(
        ...,
        description="Moderation status: safe, warning, harmful, or critical",
        examples=["safe"],
    )
    risk_score: float = Field(
        ...,
        ge=0,
        le=100,
        description="Risk score from 0 to 100",
        examples=[15.5],
    )
    categories: list[str] = Field(
        default_factory=list,
        description="List of detected harmful categories",
        examples=[[]],
    )
    reason: str = Field(
        default="",
        description="Explanation for the moderation decision",
        examples=["Content appears safe"],
    )
    confidence: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Confidence score from 0.0 to 1.0",
        examples=[0.95],
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "status": "safe",
                "risk_score": 10,
                "categories": [],
                "reason": "Content does not contain harmful material",
                "confidence": 0.98,
            }
        }
    }
