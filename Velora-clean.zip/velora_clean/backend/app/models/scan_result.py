﻿from __future__ import annotations

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from ..database import Base


class ScanResult(Base):
    __tablename__ = 'scan_result'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    content_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    file_name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    risk_score: Mapped[float] = mapped_column(Float, nullable=False)
    categories: Mapped[str] = mapped_column(Text, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self) -> str:
        return (
            f"<ScanResult(id={self.id!r}, content_type={self.content_type!r}, "
            f"status={self.status!r}, risk_score={self.risk_score!r}, "
            f"confidence={self.confidence!r}, created_at={self.created_at!r})>"
        )
