from __future__ import annotations

from datetime import datetime
from pathlib import Path
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base


class Post(Base):
    __tablename__ = 'post'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('user.id', ondelete='CASCADE'), nullable=False, index=True)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    image_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    document_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    moderation_status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    risk_score: Mapped[float] = mapped_column(Float, nullable=False)
    categories: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)

    user: Mapped['User'] = relationship('User', back_populates='posts')

    def __repr__(self) -> str:
        return (
            f"<Post(id={self.id!r}, user_id={self.user_id!r}, moderation_status={self.moderation_status!r}, "
            f"risk_score={self.risk_score!r}, created_at={self.created_at!r})>"
        )
