﻿from __future__ import annotations

import logging
import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, UploadFile, HTTPException

from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..schemas.moderation import ModerationResponse
from ..services.moderation import moderation_service

router = APIRouter(prefix="/api", tags=["moderation"])
logger = logging.getLogger(__name__)

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}


@router.post("/moderate/image", response_model=ModerationResponse)
async def moderate_image(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
) -> ModerationResponse:
    """
    Moderate image content.
    
    Supported formats: JPG, JPEG, PNG, GIF, WEBP
    Maximum file size: 10MB
    
    Response:
    - status: safe, warning, harmful, or critical
    - risk_score: 0-100
    - categories: list of detected harmful categories
    - reason: explanation of the assessment
    - confidence: 0.0-1.0 confidence in the assessment
    """
    try:
        # Validate file extension
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in ALLOWED_IMAGE_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported image format: {file_ext}. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}",
            )
        
        # Create uploads directory if not exists
        settings.images_dir.mkdir(parents=True, exist_ok=True)
        
        # Save uploaded file
        file_path = settings.images_dir / file.filename
        
        try:
            with open(file_path, "wb") as f:
                content = await file.read()
                f.write(content)
            logger.info(f"Image uploaded: {file.filename}")
        except Exception as e:
            logger.error(f"Error saving image: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to save image: {str(e)}",
            )
        
        try:
            result = await moderation_service.moderate_image(str(file_path), db)
            return ModerationResponse(**result)
        finally:
            # Clean up temporary file after processing
            try:
                if file_path.exists():
                    file_path.unlink()
                logger.info(f"Cleaned up image file: {file.filename}")
            except Exception as e:
                logger.warning(f"Failed to clean up image file: {str(e)}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in image moderation endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Moderation service error: {str(e)}",
        )
