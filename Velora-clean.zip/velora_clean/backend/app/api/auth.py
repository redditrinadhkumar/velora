from __future__ import annotations

import logging
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.user import User
from ..schemas.auth import AuthResponse, LoginRequest, RegisterRequest, TokenResponse, UserResponse
from ..services.auth_service import auth_service, create_access_token, decode_access_token

router = APIRouter(prefix='/api/auth', tags=['auth'])
logger = logging.getLogger(__name__)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='/api/auth/login')


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    try:
        payload = decode_access_token(token)
        username: str | None = payload.get('sub')
        if username is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid authentication token')
        user = db.query(User).filter(User.username == username).first()
        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='User not found')
        return user
    except Exception as exc:
        logger.error(f'Authentication failed: {exc}')
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid authentication token')


@router.post('/register', response_model=AuthResponse)
async def register_user(request: RegisterRequest, db: Session = Depends(get_db)) -> AuthResponse:
    try:
        user = auth_service.register_user(db, request)
        token = create_access_token({'sub': user.username})
        return AuthResponse(user=UserResponse.from_orm(user), token=TokenResponse(access_token=token))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except Exception as exc:
        logger.error(f'Registration failed: {exc}', exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail='Unable to register user')


@router.get('/me', response_model=UserResponse)
async def read_current_user(current_user: User = Depends(get_current_user)) -> UserResponse:
    return UserResponse.from_orm(current_user)


@router.post('/login', response_model=AuthResponse)
async def login_user(request: LoginRequest, db: Session = Depends(get_db)) -> AuthResponse:
    try:
        user = auth_service.authenticate_user(db, request)
        token = create_access_token({'sub': user.username})
        return AuthResponse(user=UserResponse.from_orm(user), token=TokenResponse(access_token=token))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc))
    except Exception as exc:
        logger.error(f'Login failed: {exc}', exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail='Unable to log in user')
