﻿from __future__ import annotations

import logging
from fastapi import APIRouter, Depends, HTTPException

from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas.moderation import ModerationRequest, ModerationResponse
from ..services.moderation import moderation_service

router = APIRouter(prefix="/api", tags=["moderation"])
logger = logging.getLogger(__name__)


@router.post("/moderate/text", response_model=ModerationResponse)
async def moderate_text(
    request: ModerationRequest,
    db: Session = Depends(get_db),
) -> ModerationResponse:
    """
    Moderate text content.
    
    Request body:
    - text: Optional text to moderate (1-10000 characters)
    
    Response:
    - status: safe, warning, harmful, or critical
    - risk_score: 0-100
    - categories: list of detected harmful categories
    - reason: explanation of the assessment
    - confidence: 0.0-1.0 confidence in the assessment
    """
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(
                status_code=400,
                detail="Text content is required and cannot be empty",
            )
        
        logger.info(f"Processing text moderation request: {len(request.text)} characters")
        
        result = await moderation_service.moderate_text(request.text, db)
        
        return ModerationResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in text moderation endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Moderation service error: {str(e)}",
        )
