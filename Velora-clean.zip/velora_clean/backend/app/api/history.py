﻿from __future__ import annotations

import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query

from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas.scan_history import ScanHistoryResponse
from ..services.moderation import moderation_service

router = APIRouter(prefix="/api", tags=["history"])
logger = logging.getLogger(__name__)


@router.get("/history", response_model=List[ScanHistoryResponse])
async def get_history(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
) -> List[ScanHistoryResponse]:
    """
    Retrieve scan history.
    
    Query parameters:
    - limit: Maximum number of results (1-1000, default 100)
    - offset: Number of results to skip (default 0)
    
    Response: List of scan history entries with timestamps
    """
    try:
        logger.info(f"Fetching scan history: limit={limit}, offset={offset}")
        
        history = moderation_service.get_scan_history(db, limit=limit, offset=offset)
        
        return [ScanHistoryResponse(**item) for item in history]
    except Exception as e:
        logger.error(f"Error retrieving history: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve scan history: {str(e)}",
        )


@router.get("/history/{scan_id}", response_model=ScanHistoryResponse)
async def get_scan_detail(
    scan_id: int,
    db: Session = Depends(get_db),
) -> ScanHistoryResponse:
    """
    Retrieve detailed scan result.
    
    Path parameters:
    - scan_id: ID of the scan result
    
    Response: Complete scan result with all details
    """
    try:
        logger.info(f"Fetching scan detail: id={scan_id}")
        
        result = moderation_service.get_scan_by_id(db, scan_id)
        if not result:
            raise HTTPException(
                status_code=404,
                detail=f"Scan result not found: {scan_id}",
            )
        
        return ScanHistoryResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving scan detail: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve scan result: {str(e)}",
        )
