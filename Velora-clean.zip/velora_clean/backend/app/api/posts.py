from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models.post import Post
from ..models.user import User
from ..schemas.post import PostFeedResponse, PostResponse
from ..services.auth_service import get_current_user
from ..services.file_processing import file_processor
from ..services.moderation import moderation_service

router = APIRouter(prefix='/api/posts', tags=['posts'])
logger = logging.getLogger(__name__)


def _cleanup_uploaded_file(path_str: str | None) -> None:
    if not path_str:
        return

    try:
        full_path = settings.uploads_dir.parent / Path(path_str)
        full_path.unlink(missing_ok=True)
    except Exception as exc:  # pragma: no cover
        logger.warning(f'Unable to remove temporary upload {path_str}: {exc}')


def _raise_for_blocked_status(moderation: dict) -> None:
    status_name = moderation.get('status')
    reason = moderation.get('reason', 'This content cannot be posted.')
    if status_name in ('harmful', 'critical'):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=reason)
    if status_name == 'error':
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=reason)


@router.post('/', response_model=PostResponse)
async def create_post(
    content: str = Form(...),
    image: UploadFile | None = File(None),
    document: UploadFile | None = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> PostResponse:
    user = current_user

    image_path = None
    document_path = None

    if image:
        target = settings.images_dir / Path(image.filename).name
        contents = await image.read()
        target.write_bytes(contents)
        image_path = str(target.relative_to(settings.uploads_dir.parent))

    if document:
        target = settings.documents_dir / Path(document.filename).name
        contents = await document.read()
        target.write_bytes(contents)
        document_path = str(target.relative_to(settings.uploads_dir.parent))

    post_data = {
        'content': content,
        'moderation_status': 'safe',
        'risk_score': 0.0,
        'categories': [],
        'image_path': image_path,
        'document_path': document_path,
    }

    if document_path:
        document_full_path = settings.uploads_dir.parent / document_path
        is_valid, message = file_processor.validate_file(document_full_path)
        if not is_valid:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
        extracted_text = file_processor.extract_text_from_file(document_full_path)
        moderation = await moderation_service.moderate_document(str(document_full_path), db)
    elif image_path:
        image_full_path = settings.uploads_dir.parent / image_path
        is_valid, message = file_processor.validate_image(image_full_path)
        if not is_valid:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
        moderation = await moderation_service.moderate_image(str(image_full_path), db)
    else:
        moderation = await moderation_service.moderate_text(content, db)

    if moderation.get('status') in ('harmful', 'critical', 'error'):
        _cleanup_uploaded_file(image_path)
        _cleanup_uploaded_file(document_path)
        _raise_for_blocked_status(moderation)

    post_data.update({
        'moderation_status': moderation['status'],
        'risk_score': moderation['risk_score'],
        'categories': moderation['categories'],
    })

    post = Post(
        user_id=user.id,
        content=post_data['content'],
        image_path=post_data['image_path'],
        document_path=post_data['document_path'],
        moderation_status=post_data['moderation_status'],
        risk_score=post_data['risk_score'],
        categories=','.join(post_data['categories']),
    )
    db.add(post)
    db.commit()
    db.refresh(post)

    return PostResponse(
        id=post.id,
        user_id=post.user_id,
        content=post.content,
        image_path=post.image_path,
        document_path=post.document_path,
        moderation_status=post.moderation_status,
        risk_score=post.risk_score,
        categories=post.categories.split(',') if post.categories else [],
        created_at=post.created_at,
    )


@router.get('/', response_model=List[PostFeedResponse])
async def list_posts(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
) -> List[PostFeedResponse]:
    posts = db.query(Post).order_by(Post.created_at.desc()).offset(skip).limit(limit).all()
    feed = []
    for post in posts:
        feed.append(PostFeedResponse(
            id=post.id,
            user_id=post.user_id,
            content=post.content,
            image_path=post.image_path,
            document_path=post.document_path,
            moderation_status=post.moderation_status,
            risk_score=post.risk_score,
            categories=post.categories.split(',') if post.categories else [],
            created_at=post.created_at,
            username=post.user.username,
        ))
    return feed


@router.get('/{post_id}', response_model=PostFeedResponse)
async def get_post(post_id: int, db: Session = Depends(get_db)) -> PostFeedResponse:
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Post not found')

    return PostFeedResponse(
        id=post.id,
        user_id=post.user_id,
        content=post.content,
        image_path=post.image_path,
        document_path=post.document_path,
        moderation_status=post.moderation_status,
        risk_score=post.risk_score,
        categories=post.categories.split(',') if post.categories else [],
        created_at=post.created_at,
        username=post.user.username,
    )
