﻿from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import Base, engine
from fastapi.staticfiles import StaticFiles
from .api.auth import router as auth_router
from .api.posts import router as posts_router
from .api.text import router as text_router
from .api.document import router as document_router
from .api.image import router as image_router
from .api.history import router as history_router

logger = logging.getLogger(__name__)


def create_directories() -> None:
    paths = [
        settings.uploads_dir,
        settings.images_dir,
        settings.documents_dir,
        settings.reports_dir,
    ]
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Ensured directory exists: {path}")


def create_database() -> None:
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created or validated.")


app = FastAPI(
    title="Velora AI Social Platform",
    description="Velora is an AI-powered social platform that analyzes posts before publishing.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(posts_router)
app.include_router(text_router)
app.include_router(document_router)
app.include_router(image_router)
app.include_router(history_router)

app.mount('/uploads', StaticFiles(directory=settings.uploads_dir), name='uploads')


@app.on_event("startup")
async def startup_event() -> None:
    logger.info("Starting AI Content Moderation backend")
    create_directories()
    create_database()


@app.get("/health")
async def health() -> dict:
    return {"status": "healthy"}
