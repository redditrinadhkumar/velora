﻿from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from ..models.scan_result import ScanResult
from ..models.audit_log import AuditLog
from .gemini_client import gemini_client
from .file_processing import file_processor, FileProcessingError

logger = logging.getLogger(__name__)


class ModerationService:
    """Orchestrate content moderation workflow."""

    @staticmethod
    async def moderate_text(text: str, db: Session) -> dict:
        """Moderate text content."""
        try:
            logger.info(f"Starting text moderation: {len(text)} characters")

            moderation_result = await gemini_client.moderate_text(text)

            scan_result = ScanResult(
                content_type="text",
                file_name=None,
                status=moderation_result["status"],
                risk_score=moderation_result["risk_score"],
                categories=",".join(moderation_result["categories"]),
                reason=moderation_result["reason"],
                confidence=moderation_result["confidence"],
                created_at=datetime.utcnow(),
            )
            db.add(scan_result)
            db.commit()
            db.refresh(scan_result)

            ModerationService._log_audit(
                db,
                "text_moderation",
                f"Text moderated: {scan_result.id}, status={moderation_result['status']}, risk_score={moderation_result['risk_score']}",
            )

            logger.info(f"Text moderation completed: ID={scan_result.id}, status={moderation_result['status']}")

            return moderation_result
        except Exception as e:
            logger.error(f"Text moderation error: {str(e)}", exc_info=True)
            ModerationService._log_audit(db, "text_moderation_error", f"Error: {str(e)}")
            raise

    @staticmethod
    async def moderate_image(image_path: str, db: Session) -> dict:
        """Moderate image content."""
        try:
            file_path = Path(image_path)
            logger.info(f"Starting image moderation: {file_path.name}")

            is_valid, message = file_processor.validate_file(file_path)
            if not is_valid:
                logger.warning(f"Image validation failed: {message}")
                return {
                    "status": "error",
                    "risk_score": 0,
                    "categories": ["validation_error"],
                    "reason": message,
                    "confidence": 1.0,
                }

            is_valid_image, message = file_processor.validate_image(file_path)
            if not is_valid_image:
                logger.warning(f"Image format validation failed: {message}")
                return {
                    "status": "error",
                    "risk_score": 0,
                    "categories": ["invalid_image"],
                    "reason": message,
                    "confidence": 1.0,
                }

            moderation_result = await gemini_client.moderate_image(image_path)

            scan_result = ScanResult(
                content_type="image",
                file_name=file_path.name,
                status=moderation_result["status"],
                risk_score=moderation_result["risk_score"],
                categories=",".join(moderation_result["categories"]),
                reason=moderation_result["reason"],
                confidence=moderation_result["confidence"],
                created_at=datetime.utcnow(),
            )
            db.add(scan_result)
            db.commit()
            db.refresh(scan_result)

            ModerationService._log_audit(
                db,
                "image_moderation",
                f"Image moderated: {scan_result.id}, file={file_path.name}, status={moderation_result['status']}",
            )

            logger.info(f"Image moderation completed: ID={scan_result.id}, status={moderation_result['status']}")

            return moderation_result
        except Exception as e:
            logger.error(f"Image moderation error: {str(e)}", exc_info=True)
            ModerationService._log_audit(db, "image_moderation_error", f"Error: {str(e)}")
            raise

    @staticmethod
    async def moderate_document(file_path: str, db: Session) -> dict:
        """Moderate document content (PDF, DOCX, TXT)."""
        try:
            path = Path(file_path)
            logger.info(f"Starting document moderation: {path.name}")

            is_valid, message = file_processor.validate_file(path)
            if not is_valid:
                logger.warning(f"Document validation failed: {message}")
                return {
                    "status": "error",
                    "risk_score": 0,
                    "categories": ["validation_error"],
                    "reason": message,
                    "confidence": 1.0,
                }

            try:
                content = file_processor.extract_text_from_file(path)
                if not content or not content.strip():
                    logger.warning("No text extracted from document")
                    return {
                        "status": "error",
                        "risk_score": 0,
                        "categories": ["empty_content"],
                        "reason": "No extractable text found in document",
                        "confidence": 1.0,
                    }
            except FileProcessingError as e:
                logger.error(f"Text extraction failed: {str(e)}")
                return {
                    "status": "error",
                    "risk_score": 0,
                    "categories": ["extraction_error"],
                    "reason": str(e),
                    "confidence": 1.0,
                }

            moderation_result = await gemini_client.moderate_document(content)

            scan_result = ScanResult(
                content_type="document",
                file_name=path.name,
                status=moderation_result["status"],
                risk_score=moderation_result["risk_score"],
                categories=",".join(moderation_result["categories"]),
                reason=moderation_result["reason"],
                confidence=moderation_result["confidence"],
                created_at=datetime.utcnow(),
            )
            db.add(scan_result)
            db.commit()
            db.refresh(scan_result)

            ModerationService._log_audit(
                db,
                "document_moderation",
                f"Document moderated: {scan_result.id}, file={path.name}, status={moderation_result['status']}",
            )

            logger.info(f"Document moderation completed: ID={scan_result.id}, status={moderation_result['status']}")

            return moderation_result
        except Exception as e:
            logger.error(f"Document moderation error: {str(e)}", exc_info=True)
            ModerationService._log_audit(db, "document_moderation_error", f"Error: {str(e)}")
            raise

    @staticmethod
    def get_scan_history(db: Session, limit: int = 100, offset: int = 0) -> list[dict]:
        """Retrieve scan history."""
        try:
            results = (
                db.query(ScanResult)
                .order_by(ScanResult.created_at.desc())
                .offset(offset)
                .limit(limit)
                .all()
            )

            history = []
            for result in results:
                history.append({
                    "id": result.id,
                    "content_type": result.content_type,
                    "file_name": result.file_name,
                    "status": result.status,
                    "risk_score": result.risk_score,
                    "categories": result.categories.split(",") if result.categories else [],
                    "created_at": result.created_at.isoformat(),
                })

            return history
        except Exception as e:
            logger.error(f"Error retrieving scan history: {str(e)}", exc_info=True)
            raise

    @staticmethod
    def get_scan_by_id(db: Session, scan_id: int) -> dict | None:
        """Retrieve specific scan result."""
        try:
            result = db.query(ScanResult).filter(ScanResult.id == scan_id).first()
            if not result:
                return None

            return {
                "id": result.id,
                "content_type": result.content_type,
                "file_name": result.file_name,
                "status": result.status,
                "risk_score": result.risk_score,
                "categories": result.categories.split(",") if result.categories else [],
                "reason": result.reason,
                "confidence": result.confidence,
                "created_at": result.created_at.isoformat(),
            }
        except Exception as e:
            logger.error(f"Error retrieving scan {scan_id}: {str(e)}", exc_info=True)
            raise

    @staticmethod
    def _log_audit(db: Session, event_type: str, details: str) -> None:
        """Log audit event."""
        try:
            audit_log = AuditLog(
                event_type=event_type,
                details=details,
                created_at=datetime.utcnow(),
            )
            db.add(audit_log)
            db.commit()
        except Exception as e:
            logger.error(f"Error logging audit event: {str(e)}")


# Create singleton instance
moderation_service = ModerationService()
