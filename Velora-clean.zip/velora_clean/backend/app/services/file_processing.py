﻿from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from PIL import Image
import PyPDF2
from docx import Document

logger = logging.getLogger(__name__)

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
ALLOWED_IMAGE_FORMATS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
ALLOWED_DOCUMENT_FORMATS = {".pdf", ".docx", ".txt"}
ALLOWED_FORMATS = ALLOWED_IMAGE_FORMATS | ALLOWED_DOCUMENT_FORMATS


class FileProcessingError(Exception):
    """Custom exception for file processing errors."""
    pass


class FileProcessor:
    """Handle file extraction and validation."""

    @staticmethod
    def validate_file(file_path: Path) -> tuple[bool, str]:
        """Validate file exists, format, and size."""
        if not file_path.exists():
            return False, "File does not exist"
        
        # Check file extension
        suffix = file_path.suffix.lower()
        if suffix not in ALLOWED_FORMATS:
            return False, f"Unsupported file format: {suffix}"
        
        # Check file size
        file_size = file_path.stat().st_size
        if file_size > MAX_FILE_SIZE:
            return False, f"File size {file_size} bytes exceeds maximum {MAX_FILE_SIZE} bytes"
        
        if file_size == 0:
            return False, "File is empty"
        
        return True, "Valid"

    @staticmethod
    def extract_text_from_file(file_path: Path) -> str:
        """Extract text from TXT, PDF, or DOCX file."""
        suffix = file_path.suffix.lower()
        
        try:
            if suffix == ".txt":
                return FileProcessor._extract_txt(file_path)
            elif suffix == ".pdf":
                return FileProcessor._extract_pdf(file_path)
            elif suffix == ".docx":
                return FileProcessor._extract_docx(file_path)
            else:
                raise FileProcessingError(f"Unsupported format: {suffix}")
        except FileProcessingError as e:
            logger.error(f"File processing error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error extracting text: {str(e)}", exc_info=True)
            raise FileProcessingError(f"Failed to extract text: {str(e)}")

    @staticmethod
    def _extract_txt(file_path: Path) -> str:
        """Extract text from TXT file."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            logger.info(f"Extracted {len(content)} characters from TXT: {file_path.name}")
            return content
        except UnicodeDecodeError:
            # Try with different encoding
            try:
                with open(file_path, "r", encoding="latin-1") as f:
                    content = f.read()
                logger.info(f"Extracted {len(content)} characters from TXT (latin-1): {file_path.name}")
                return content
            except Exception as e:
                raise FileProcessingError(f"Failed to decode TXT file: {str(e)}")
        except Exception as e:
            raise FileProcessingError(f"Error reading TXT file: {str(e)}")

    @staticmethod
    def _extract_pdf(file_path: Path) -> str:
        """Extract text from PDF file using PyPDF2."""
        try:
            content = []
            with open(file_path, "rb") as f:
                pdf_reader = PyPDF2.PdfReader(f)
                page_count = len(pdf_reader.pages)
                
                for page_num, page in enumerate(pdf_reader.pages):
                    try:
                        text = page.extract_text()
                        if text:
                            content.append(text)
                    except Exception as e:
                        logger.warning(f"Failed to extract text from PDF page {page_num + 1}: {str(e)}")
            
            extracted_text = "\n".join(content)
            logger.info(f"Extracted {len(extracted_text)} characters from PDF ({page_count} pages): {file_path.name}")
            return extracted_text
        except Exception as e:
            raise FileProcessingError(f"Error reading PDF file: {str(e)}")

    @staticmethod
    def _extract_docx(file_path: Path) -> str:
        """Extract text from DOCX file using python-docx."""
        try:
            doc = Document(file_path)
            content = []
            
            for para in doc.paragraphs:
                if para.text:
                    content.append(para.text)
            
            extracted_text = "\n".join(content)
            logger.info(f"Extracted {len(extracted_text)} characters from DOCX: {file_path.name}")
            return extracted_text
        except Exception as e:
            raise FileProcessingError(f"Error reading DOCX file: {str(e)}")

    @staticmethod
    def validate_image(file_path: Path) -> tuple[bool, str]:
        """Validate image file using Pillow."""
        suffix = file_path.suffix.lower()
        
        if suffix not in ALLOWED_IMAGE_FORMATS:
            return False, f"Unsupported image format: {suffix}"
        
        try:
            with Image.open(file_path) as img:
                # Verify image can be loaded
                img.verify()
            logger.info(f"Image validation passed: {file_path.name}")
            return True, "Valid image"
        except Exception as e:
            logger.error(f"Image validation failed: {str(e)}")
            return False, f"Invalid image file: {str(e)}"


# Create singleton instance
file_processor = FileProcessor()
