﻿from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


# Resolve the project root from this config module.
# When uvicorn is started from backend/, this still points to the repo root.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_FILE_PATH = PROJECT_ROOT / '.env'


class Settings(BaseSettings):
    gemini_api_key: str
    database_url: str = 'sqlite:///./app.db'
    jwt_secret_key: str = 'velora_local_secret'
    jwt_algorithm: str = 'HS256'
    uploads_dir: Path = Path('uploads')
    images_dir: Path = uploads_dir / 'images'
    documents_dir: Path = uploads_dir / 'documents'
    reports_dir: Path = Path('reports')

    model_config = SettingsConfigDict(
        env_file=ENV_FILE_PATH,
        env_file_encoding='utf-8',
        env_prefix='',
        case_sensitive=False,
    )


settings = Settings()
