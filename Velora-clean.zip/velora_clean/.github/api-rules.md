# Gemini API Rules

Use Gemini 2.5 Flash.

Environment Variable:

GEMINI_API_KEY

Never hardcode API keys.

Use structured JSON output.

Required Response:

{
  "status": "",
  "risk_score": 0,
  "categories": [],
  "reason": ""
}

Retry Logic:

- 3 retries
- Exponential backoff

Timeout:

30 seconds

Notes:

- This is a local network application, not a cloud service.
- All Gemini requests must be secured server-side and never exposed to the browser.
- No cloud storage assumptions should be made.