# Functional Requirements

## User Features

- Paste text for moderation
- Upload JPG, JPEG, PNG images
- Upload PDF documents
- Upload DOCX documents
- Upload TXT text files
- View moderation results and risk score
- Access local scan history
- Export moderation reports

## AI Features

Analyze content using Gemini.

Return:

{
  "status": "safe",
  "risk_score": 10,
  "categories": [],
  "reason": ""
}

## Categories

- Safe
- Hate Speech
- Violence
- Harassment
- Terrorism
- Self Harm
- Sexual Content
- Child Safety
- Illegal Activity
- Prompt Injection
- Jailbreak

## Dashboard

- Single-user local moderation dashboard
- No authentication
- Local network access via localhost and LAN IP
- Upload files and paste text from the dashboard
- View scan history and flagged content
- Download reports from local storage

## Storage

- SQLite database for scan history
- Local filesystem uploads under uploads/images and uploads/documents
- Reports saved under reports/

## Application Type

Local-only moderation application.

Runs on a local machine and is accessible via localhost and the same-network LAN IP.

No login, registration, user management, or authentication required.