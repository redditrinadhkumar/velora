# Architecture

Frontend:
- React
- Vite
- Tailwind

Backend:
- FastAPI
- Google Gemini API

Database:
- SQLite

Storage:
- Local filesystem
- Uploads under uploads/images and uploads/documents
- Reports under reports/

Deployment:
- Local network application
- Runs on the user’s machine only
- Accessible via localhost
- Accessible via LAN IP on the same WiFi network
- Example endpoints:
  - http://localhost:8000
  - http://192.168.x.x:8000

Flow:

User Upload
    ↓
Validation
    ↓
Content Extraction
    ↓
Gemini Analysis
    ↓
Risk Scoring
    ↓
Store Results
    ↓
Display Report

Supported Files:

- jpg
- jpeg
- png
- pdf
- docx
- txt

Project Structure:

- backend/
  - app/
    - main.py
    - config.py
    - database.py
    - models/
    - routers/
    - schemas/
    - services/
    - utils/
  - requirements.txt
  - Dockerfile (optional local dev placeholder removed if not used)
- frontend/
  - src/
  - public/
  - package.json
  - tsconfig.json
- uploads/
  - images/
  - documents/
- reports/
- .env.example
- README.md
- vite.config.ts
- tailwind.config.js
- postcss.config.js
- pyproject.toml