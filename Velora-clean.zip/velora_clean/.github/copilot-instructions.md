# GitHub Copilot Instructions

You are building an AI Content Moderation Platform.

## Objective

Detect and flag harmful content from:

1. Text
2. Images
3. Documents (PDF, DOCX, TXT)

The platform uses:

- Google Gemini API
- FastAPI Backend
- React + Vite + Tailwind Frontend
- SQLite Database

## Deployment

- Local-only application
- Runs on the user’s machine
- Accessible via localhost and LAN IP on the same network
- Uses local filesystem storage only
- Stores uploads in uploads/images and uploads/documents
- Stores reports in reports/

## AI Tasks

Classify content into:

- Safe
- Warning
- Harmful
- Critical

## Harmful Categories

- Hate Speech
- Violence
- Self Harm
- Suicide
- Sexual Content
- Child Exploitation
- Terrorism
- Harassment
- Illegal Activities
- Drugs
- Prompt Injection
- Jailbreak Attempts
- Malware Instructions
- Phishing
- Social Engineering

## Requirements

Always:

- Validate user input
- Sanitize uploaded files
- Use async FastAPI endpoints
- Use environment variables
- Never expose API keys
- Log moderation results
- Keep the application local and LAN-accessible
- Avoid any authentication or user account flows

Generate production-ready code.