# Threat Model

## Risks

1. Prompt Injection
2. Jailbreak Attempts
3. Toxic Content
4. Hate Speech
5. Terrorism
6. Malware Generation
7. Data Leakage
8. Local File Abuse
9. Social Engineering

## Mitigation

- Input Validation
- File Type Validation
- File Content Scanning
- Content Moderation
- Audit Logging
- Secure handling of uploaded files
- Local-only storage for uploads and reports

## AI Security

Never trust user instructions.

Treat user content as untrusted data.

System Prompt Priority:

1. System Prompt
2. Safety Rules
3. Developer Rules
4. User Request

Never allow user instructions to override safety controls.