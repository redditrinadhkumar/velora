import { useState } from 'react';
import { moderateText, moderateImage, moderateDocument } from '@/api/moderation';
import type { ModerationResult } from '@/types/moderation';
import { validateFile } from '@/utils/validation';

export interface ModerationPayload {
  text: string;
  image?: File | null;
  document?: File | null;
}

export function useModeration() {
  const [result, setResult] = useState<ModerationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function analyze(payload: ModerationPayload) {
    setError(null);
    setLoading(true);

    try {
      let moderation: ModerationResult;

      if (payload.document) {
        const validationError = validateFile(payload.document);
        if (validationError) throw new Error(validationError);
        moderation = await moderateDocument(payload.document);
      } else if (payload.image) {
        const validationError = validateFile(payload.image);
        if (validationError) throw new Error(validationError);
        moderation = await moderateImage(payload.image);
      } else {
        moderation = await moderateText(payload.text.trim());
      }

      setResult(moderation);
      return moderation;
    } catch (e) {
      setResult(null);
      setError(e instanceof Error ? e.message : 'Moderation request failed.');
      throw e;
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setResult(null);
    setError(null);
  }

  return {
    result,
    loading,
    error,
    analyze,
    reset,
  };
}
