import type { ScanHistoryItem } from '@/types/moderation';

export function formatDate(value: string): string {
  const date = new Date(value);
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}

export function summarizeHistory(items: ScanHistoryItem[]) {
  return items.map((item) => ({
    ...item,
    categories: Array.isArray(item.categories) ? item.categories : item.categories || [],
  }));
}
