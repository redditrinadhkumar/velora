export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function validateFile(file: File): string | null {
  if (!file) {
    return 'No file selected.';
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return `File size must be smaller than ${formatBytes(MAX_UPLOAD_BYTES)}.`;
  }
  return null;
}
