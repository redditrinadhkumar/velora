import { NavLink, Route, Routes } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import CreatePost from '@/pages/CreatePost';
import Feed from '@/pages/Feed';
import History from '@/pages/History';
import Analytics from '@/pages/Analytics';
import Profile from '@/pages/Profile';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ProtectedRoute from '@/components/ProtectedRoute';

const navItems = [
  { label: 'Home', to: '/' },
  { label: 'Create Post', to: '/create' },
  { label: 'Profile', to: '/profile' },
  { label: 'History', to: '/history' },
  { label: 'Analytics', to: '/analytics' },
];

function App() {
  const { user, signOut } = useAuth();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto flex max-w-7xl flex-col lg:flex-row">
        <aside className="w-full border-b border-slate-800 bg-slate-900 p-6 lg:w-72 lg:border-b-0 lg:border-r lg:sticky lg:top-0 lg:h-screen">
          <div className="mb-8 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-500 text-2xl font-bold text-slate-950">
              V
            </div>
            <div>
              <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Velora</p>
              <h1 className="text-xl font-semibold text-white">Post Freely.</h1>
              <p className="text-xs text-slate-400">Post Safely.</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `block rounded-2xl px-4 py-3 text-sm font-medium transition ${
                    isActive ? 'bg-slate-800 text-cyan-300' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`
                }
                end={item.to === '/'}
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-950/70 p-5 text-sm text-slate-400">
            <p className="mb-3 text-slate-200 font-semibold">Safety at every step</p>
            <p>Velora analyzes every post before publishing to keep your community safe.</p>
          </div>

          <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-950/70 p-5 text-sm text-slate-400">
            <p className="text-slate-200 font-semibold">Trending categories</p>
            <div className="mt-4 space-y-2 text-slate-300">
              <span className="inline-flex rounded-full bg-slate-900 px-3 py-2">Misinformation</span>
              <span className="inline-flex rounded-full bg-slate-900 px-3 py-2">Harassment</span>
              <span className="inline-flex rounded-full bg-slate-900 px-3 py-2">Self-harm</span>
            </div>
          </div>

          <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-950/70 p-5 text-sm text-slate-400">
            <p className="text-slate-200 font-semibold">Account</p>
            {user ? (
              <div className="mt-3 space-y-3">
                <p className="text-slate-300">Signed in as</p>
                <p className="text-white font-semibold">{user.username}</p>
                <button
                  type="button"
                  onClick={signOut}
                  className="mt-2 inline-flex w-full justify-center rounded-3xl bg-red-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-red-400"
                >
                  Sign out
                </button>
              </div>
            ) : (
              <div className="mt-3 space-y-3">
                <NavLink
                  to="/login"
                  className="inline-flex w-full justify-center rounded-3xl bg-cyan-500 px-4 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400"
                >
                  Sign in
                </NavLink>
                <NavLink
                  to="/register"
                  className="inline-flex w-full justify-center rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-sm font-semibold text-slate-100 transition hover:border-cyan-400"
                >
                  Register
                </NavLink>
              </div>
            )}
          </div>
        </aside>

        <main className="flex-1 p-6">
          <Routes>
            <Route path="/" element={<Feed />} />
            <Route path="/create" element={<ProtectedRoute><CreatePost /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/history" element={<ProtectedRoute><History /></ProtectedRoute>} />
            <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default App;
