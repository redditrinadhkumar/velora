import { useEffect, useState } from 'react';
import { listPosts } from '@/api/posts';
import type { PostFeedResponse } from '@/types/post';
import { formatDate } from '@/utils/format';
import ResultBadge from '@/components/ResultBadge';

export default function Feed() {
  const [posts, setPosts] = useState<PostFeedResponse[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listPosts().then(setPosts).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Home feed</p>
        <h2 className="text-3xl font-semibold text-white">Velora community feed</h2>
        <p className="max-w-2xl text-slate-400">Browse the latest community posts reviewed by Velora.</p>
      </header>

      {loading ? (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">Loading posts...</div>
      ) : posts.length ? (
        <div className="grid gap-6 lg:grid-cols-2">
          {posts.map((post) => (
            <article key={post.id} className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm transition hover:border-cyan-400/30">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-slate-400">{formatDate(post.created_at)}</p>
                  <h3 className="mt-2 text-xl font-semibold text-white">{post.username}</h3>
                </div>
                <ResultBadge status={post.moderation_status as any} />
              </div>
              <p className="mt-4 text-slate-200">{post.content}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-sm text-slate-300">
                <span className="rounded-full bg-slate-900 px-3 py-2">Risk {post.risk_score.toFixed(0)}%</span>
                <span className="rounded-full bg-slate-900 px-3 py-2">{post.categories.join(', ') || 'No categories'}</span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">No posts have been published yet.</div>
      )}
    </div>
  );
}
