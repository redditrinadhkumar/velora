import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

export default function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { signUp } = useAuth();

  return (
    <div className="mx-auto max-w-md space-y-8 rounded-3xl border border-slate-800 bg-slate-950 p-8 shadow-sm">
      <div className="space-y-3 text-center">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Create account</p>
        <h1 className="text-3xl font-semibold text-white">Join Velora</h1>
        <p className="text-sm text-slate-400">Register to publish safely with AI-powered content moderation.</p>
      </div>

      <form
        className="space-y-5"
        onSubmit={async (event) => {
          event.preventDefault();
          setError(null);
          setLoading(true);
          try {
            await signUp({ username, email, password });
            navigate('/');
          } catch (err) {
            setError(err instanceof Error ? err.message : 'Registration failed.');
          } finally {
            setLoading(false);
          }
        }}
      >
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-slate-200">Username</label>
          <input
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            className="w-full rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500"
          />
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-semibold text-slate-200">Email</label>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="w-full rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500"
          />
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-semibold text-slate-200">Password</label>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="w-full rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500"
          />
        </div>

        {error ? <p className="rounded-3xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p> : null}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading ? 'Creating account...' : 'Sign up'}
        </button>
      </form>

      <p className="text-center text-sm text-slate-400">
        Already have an account?{' '}
        <button type="button" className="text-cyan-300 hover:text-white" onClick={() => navigate('/login')}>
          Sign in
        </button>
      </p>
    </div>
  );
}
