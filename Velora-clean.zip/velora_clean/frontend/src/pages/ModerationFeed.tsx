import { useEffect, useState } from 'react';
import { getHistory } from '@/api/moderation';
import type { ScanHistoryItem } from '@/types/moderation';
import ResultBadge from '@/components/ResultBadge';
import { formatDate } from '@/utils/format';

export default function ModerationFeed() {
  const [feed, setFeed] = useState<ScanHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHistory(15).then(setFeed).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Moderation feed</p>
        <h2 className="text-3xl font-semibold text-white">Live moderation feed</h2>
        <p className="max-w-2xl text-slate-400">See recently analyzed content and current moderation status.</p>
      </header>

      <div className="grid gap-6">
        {loading ? (
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">Fetching feed...</div>
        ) : feed.length ? (
          feed.map((item) => (
            <article key={item.id} className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm transition hover:border-cyan-400/30">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-slate-400">{formatDate(item.created_at)}</p>
                  <h3 className="mt-2 text-xl font-semibold text-white">{item.file_name ?? item.content_type}</h3>
                </div>
                <ResultBadge status={item.status as any} />
              </div>
              <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-300">
                <span className="rounded-2xl bg-slate-900 px-3 py-2">Risk {item.risk_score.toFixed(0)}%</span>
                <span className="rounded-2xl bg-slate-900 px-3 py-2">{item.categories.join(', ') || 'No categories'}</span>
              </div>
            </article>
          ))
        ) : (
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">No feed items are available.</div>
        )}
      </div>
    </div>
  );
}
