import { useState } from 'react';
import FileUploader from '@/components/FileUploader';
import { useModeration } from '@/hooks/useModeration';
import DocumentModerationCard from '@/components/DocumentModerationCard';
import ResultBadge from '@/components/ResultBadge';

export default function DocumentModeration() {
  const [file, setFile] = useState<File | null>(null);
  const { result, loading, error, analyze } = useModeration();

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Document moderation</p>
        <h2 className="text-3xl font-semibold text-white">Analyze uploaded documents</h2>
        <p className="max-w-2xl text-slate-400">Upload a PDF, DOCX, or TXT file and verify its moderation status.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <FileUploader label="Select document to moderate" accept=".pdf,.docx,.txt" file={file} onChange={setFile} />
          <button
            type="button"
            disabled={!file || loading}
            onClick={() => file && analyze({ text: '', document: file })}
            className="mt-6 inline-flex items-center justify-center rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Analyze Document'}
          </button>
          {error ? <p className="mt-4 rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-200">{error}</p> : null}
        </div>

        <aside className="space-y-6">
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Current status</p>
                <h3 className="text-xl font-semibold text-white">{file?.name ?? 'No document selected'}</h3>
              </div>
              <ResultBadge status={(result?.status ?? 'unknown') as any} />
            </div>
            {result ? <DocumentModerationCard result={result} fileName={file?.name ?? 'Unknown'} /> : <p className="mt-4 text-sm text-slate-400">Analyze a document to view the moderation outcome.</p>}
          </div>
        </aside>
      </div>
    </div>
  );
}
