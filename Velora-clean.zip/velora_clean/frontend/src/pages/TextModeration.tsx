import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useModeration } from '@/hooks/useModeration';
import FileUploader from '@/components/FileUploader';
import TextModerationCard from '@/components/TextModerationCard';
import ResultBadge from '@/components/ResultBadge';
import type { ModerationResult } from '@/types/moderation';

const initialText = 'This post will be reviewed by Velora before it is published.';

function StatusHint({ result }: { result: ModerationResult | null }) {
  if (!result) return null;
  if (result.status === 'warning') {
    return <p className="rounded-3xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm text-amber-200">Warning results may still be posted after confirmation. Review detected categories and reason carefully.</p>;
  }
  if (result.status === 'harmful' || result.status === 'critical') {
    return <p className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-200">Publishing is disabled for harmful or critical content. Update your text or remove attachments and analyze again.</p>;
  }
  return null;
}

export default function TextModeration() {
  const [text, setText] = useState(initialText);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [posted, setPosted] = useState(false);
  const [warningConfirmed, setWarningConfirmed] = useState(false);
  const { result, loading, error, analyze, reset } = useModeration();
  const navigate = useNavigate();

  const canPost = useMemo(() => {
    if (!result) return false;
    return result.status === 'safe' || result.status === 'warning';
  }, [result]);

  const modeLabel = documentFile
    ? 'Document moderation selected'
    : imageFile
    ? 'Image moderation selected'
    : 'Text moderation selected';

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Create Post</p>
        <h2 className="text-3xl font-semibold text-white">Compose and analyze your content</h2>
        <p className="max-w-2xl text-slate-400">Write a message, attach media, and verify safety before posting.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <section className="space-y-6 rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <div className="rounded-3xl border border-slate-800 bg-slate-900/70 px-4 py-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Publishing workflow</p>
                <h3 className="text-xl font-semibold text-white">Draft your post</h3>
              </div>
              <ResultBadge status={(result?.status ?? 'unknown') as any} />
            </div>
          </div>

          <textarea
            value={text}
            onChange={(event) => setText(event.target.value)}
            rows={10}
            className="w-full resize-none rounded-3xl border border-slate-800 bg-slate-900 px-5 py-4 text-slate-100 outline-none transition focus:border-cyan-500"
          />

          <div className="grid gap-4 lg:grid-cols-2">
            <FileUploader label="Upload image" accept="image/*" file={imageFile} onChange={(file) => { setImageFile(file); if (file) setDocumentFile(null); }} />
            <FileUploader label="Upload document" accept=".pdf,.docx,.txt" file={documentFile} onChange={(file) => { setDocumentFile(file); if (file) setImageFile(null); }} />
          </div>

          <p className="text-sm text-slate-400">{modeLabel}. Attachments take precedence over text when analyzing.</p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={loading}
              onClick={() => {
                setPosted(false);
                setWarningConfirmed(false);
                analyze({ text, image: imageFile, document: documentFile }).catch(() => {});
              }}
              className="inline-flex items-center justify-center rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? 'Analyzing...' : 'Analyze Post'}
            </button>
            <button
              type="button"
              disabled={!canPost || loading}
              onClick={() => {
                if (result?.status === 'warning' && !warningConfirmed) {
                  setWarningConfirmed(true);
                  return;
                }
                setPosted(true);
              }}
              className="inline-flex items-center justify-center rounded-3xl border border-slate-800 bg-slate-900 px-6 py-3 text-sm font-semibold text-slate-100 transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {result?.status === 'warning' && !warningConfirmed ? 'Confirm Warning' : 'Post'}
            </button>
          </div>

          {error ? <p className="rounded-3xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p> : null}
          {posted ? <p className="rounded-3xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200">Content submitted successfully. This is a mock post flow.</p> : null}

          <div className="grid gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => navigate('/feed')}
              className="rounded-3xl border border-slate-800 bg-slate-900 px-5 py-3 text-sm text-slate-200 transition hover:border-cyan-400 hover:text-cyan-300"
            >
              View Moderation Feed
            </button>
            <button
              type="button"
              onClick={() => reset()}
              className="rounded-3xl border border-slate-800 bg-slate-900 px-5 py-3 text-sm text-slate-200 transition hover:border-cyan-400 hover:text-cyan-300"
            >
              Reset Analysis
            </button>
          </div>
        </section>

        <aside className="space-y-6">
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-white">Moderation summary</h3>
            {result ? <TextModerationCard result={result} /> : <p className="mt-4 text-sm text-slate-400">Run an analysis to see status, risk score, categories, and confidence.</p>}
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-white">Publishing rules</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-300">
              <li>Safe: allow post.</li>
              <li>Warning: confirm before posting.</li>
              <li>Harmful: disable Post button.</li>
              <li>Critical: block posting completely.</li>
            </ul>
          </div>

          <StatusHint result={result} />
        </aside>
      </div>
    </div>
  );
}
