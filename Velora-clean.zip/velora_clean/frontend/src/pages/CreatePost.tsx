import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPost } from '@/api/posts';
import { moderateText, moderateImage, moderateDocument } from '@/api/moderation';
import { useAuth } from '@/contexts/AuthContext';
import FileUploader from '@/components/FileUploader';
import type { ModerationResult } from '@/types/moderation';
import type { PostFeedResponse } from '@/types/post';

const initialText = 'Write something positive and community-safe for Velora.';

export default function CreatePost() {
  const { user } = useAuth();
  const [content, setContent] = useState(initialText);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [status, setStatus] = useState<PostFeedResponse | null>(null);
  const [moderation, setModeration] = useState<ModerationResult | null>(null);
  const [blocked, setBlocked] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const canSubmit = useMemo(() => {
    if (blocked) return false;
    if (!content.trim()) return false;
    if (!moderation) return true;
    return moderation.status !== 'harmful' && moderation.status !== 'critical' && moderation.status !== 'error';
  }, [content, moderation, blocked]);

  async function runModeration(): Promise<ModerationResult> {
    if (documentFile) {
      return moderateDocument(documentFile);
    }
    if (imageFile) {
      return moderateImage(imageFile);
    }
    return moderateText(content.trim());
  }

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Create post</p>
        <h2 className="text-3xl font-semibold text-white">Publish content with Velora moderation</h2>
        <p className="max-w-2xl text-slate-400">Create a text, image, or document post that is reviewed before reaching the community.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.65fr_1fr]">
        <section className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <div className="grid gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-200">Post text</label>
              <textarea
                value={content}
                onChange={(event) => {
                  setContent(event.target.value);
                  if (blocked) setBlocked(false);
                }}
                rows={8}
                className="mt-3 w-full resize-none rounded-3xl border border-slate-800 bg-slate-900 px-5 py-4 text-slate-100 outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <FileUploader label="Attach image" accept="image/*" file={imageFile} onChange={(file) => { setImageFile(file); if (file) setDocumentFile(null); if (blocked) setBlocked(false); }} />
              <FileUploader label="Attach document" accept=".pdf,.docx,.txt" file={documentFile} onChange={(file) => { setDocumentFile(file); if (file) setImageFile(null); if (blocked) setBlocked(false); }} />
            </div>

            {error ? <div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-200">{error}</div> : null}

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                disabled={!canSubmit || loading}
                onClick={async () => {
                  setError(null);
                  setLoading(true);
                  try {
                    if (imageFile) {
                      const validationError = validateFile(imageFile);
                      if (validationError) throw new Error(validationError);
                    }
                    if (documentFile) {
                      const validationError = validateFile(documentFile);
                      if (validationError) throw new Error(validationError);
                    }

                    const moderationResult = await runModeration();
                    setModeration(moderationResult);

                    if (moderationResult.status === 'harmful' || moderationResult.status === 'critical') {
                      setBlocked(true);
                      setModalMessage('This content violates Velora community rules and cannot be posted.');
                      setShowModal(true);
                      setError('Blocked content cannot be posted.');
                      return;
                    }

                    if (moderationResult.status === 'error') {
                      setModalMessage('This content violates Velora community rules and cannot be posted.');
                      setShowModal(true);
                      setError('Unable to safely moderate content.');
                      return;
                    }

                    const post = await createPost({ content: content.trim(), image: imageFile, document: documentFile });
                    setStatus(post);
                    setContent('');
                    setImageFile(null);
                    setDocumentFile(null);
                    setModeration(null);
                    setBlocked(false);
                    setModalMessage('');
                  } catch (err) {
                    const message = err instanceof Error ? err.message : 'Unable to publish post.';
                    if (/403|Forbidden/.test(message)) {
                      setBlocked(true);
                      setModalMessage('This content violates Velora community rules and cannot be posted.');
                      setShowModal(true);
                    }
                    setError(message);
                  } finally {
                    setLoading(false);
                  }
                }}
                className="rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {loading ? 'Publishing...' : 'Publish post'}
              </button>
              <button
                type="button"
                onClick={() => navigate('/feed')}
                className="rounded-3xl border border-slate-800 bg-slate-900 px-6 py-3 text-sm font-semibold text-slate-100 transition hover:border-cyan-400 hover:text-cyan-300"
              >
                View feed
              </button>
            </div>
          </div>
        </section>

        <aside className="space-y-4">
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-white">Current user</h3>
            <p className="mt-3 text-sm text-slate-400">{user ? `Publishing as ${user.username}` : 'Sign in to publish posts.'}</p>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-white">Publish rules</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-300">
              <li>Fast text and attachment moderation.</li>
              <li>Images and documents are scanned before create.</li>
              <li>Only authenticated users may create posts.</li>
            </ul>
          </div>

          {status ? (
            <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 text-sm text-slate-200">
              <h3 className="text-base font-semibold text-white">Post reviewed</h3>
              <p className="mt-3 text-slate-400">Status: {status.moderation_status}</p>
              <p className="mt-1 text-slate-400">Risk: {status.risk_score.toFixed(0)}%</p>
            </div>
          ) : null}

          {showModal ? (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 px-4">
              <div className="max-w-xl rounded-3xl border border-red-500 bg-slate-950 p-8 shadow-xl">
                <h3 className="text-xl font-semibold text-white">Posting blocked</h3>
                <p className="mt-4 text-sm text-slate-300">{modalMessage}</p>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="mt-6 inline-flex rounded-3xl bg-cyan-500 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400"
                >
                  Dismiss
                </button>
              </div>
            </div>
          ) : null}
        </aside>
      </div>
    </div>
  );
}
