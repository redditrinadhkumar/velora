import { useEffect, useMemo, useState } from 'react';
import { getHistory } from '@/api/moderation';
import type { ScanHistoryItem } from '@/types/moderation';

export default function Analytics() {
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHistory(100).then(setHistory).finally(() => setLoading(false));
  }, []);

  const stats = useMemo(() => {
    const counts: Record<string, number> = { safe: 0, warning: 0, harmful: 0, critical: 0 };
    const categoryTotals: Record<string, number> = {};

    history.forEach((item) => {
      const status = item.status.toLowerCase();
      if (status in counts) counts[status] += 1;
      item.categories.forEach((category) => {
        categoryTotals[category] = (categoryTotals[category] ?? 0) + 1;
      });
    });

    const topCategories = Object.entries(categoryTotals)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    return { counts, topCategories };
  }, [history]);

  const total = history.length || 1;
  const safeRate = ((stats.counts.safe / total) * 100).toFixed(0);

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Analytics</p>
        <h2 className="text-3xl font-semibold text-white">Moderation statistics</h2>
        <p className="max-w-2xl text-slate-400">Track safety trends and category volume from the backend history.</p>
      </header>

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Total scans</p>
          <p className="mt-4 text-4xl font-semibold text-white">{history.length}</p>
        </div>
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Safe rate</p>
          <p className="mt-4 text-4xl font-semibold text-white">{safeRate}%</p>
        </div>
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Critical scans</p>
          <p className="mt-4 text-4xl font-semibold text-white">{stats.counts.critical}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-white">Top categories</h3>
          <p className="mt-2 text-sm text-slate-400">Most common moderation tags in recent scans.</p>
          <div className="mt-5 space-y-3">
            {stats.topCategories.length ? (
              stats.topCategories.map(([category, count]) => (
                <div key={category} className="flex items-center justify-between rounded-3xl bg-slate-900 px-4 py-3 text-sm text-slate-200">
                  <span>{category}</span>
                  <span className="font-semibold text-cyan-300">{count}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">No category data available yet.</p>
            )}
          </div>
        </section>

        <section className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white">Export insights</h3>
              <p className="mt-2 text-sm text-slate-400">Download the latest scan history for reporting.</p>
            </div>
          </div>
          <div className="mt-6">
            <button
              type="button"
              onClick={() => {
                const content = JSON.stringify(history, null, 2);
                const blob = new Blob([content], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = 'velora-analytics.json';
                document.body.appendChild(link);
                link.click();
                link.remove();
                URL.revokeObjectURL(url);
              }}
              className="rounded-3xl border border-slate-800 bg-cyan-500 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400"
            >
              Export analytics JSON
            </button>
          </div>
        </section>
      </div>

      {loading ? <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">Loading analytics...</div> : null}
    </div>
  );
}
