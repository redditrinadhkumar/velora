import { useEffect, useMemo, useState } from 'react';
import { getHistory } from '@/api/moderation';
import type { ScanHistoryItem } from '@/types/moderation';
import ReportExportButton from '@/components/ReportExportButton';
import { formatDate } from '@/utils/format';
import ResultBadge from '@/components/ResultBadge';

function summaryCard(title: string, value: string, description: string) {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
      <p className="text-sm uppercase tracking-[0.24em] text-slate-500">{title}</p>
      <p className="mt-4 text-3xl font-semibold text-white">{value}</p>
      <p className="mt-2 text-sm text-slate-400">{description}</p>
    </div>
  );
}

export default function Dashboard() {
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHistory(10).then(setHistory).finally(() => setLoading(false));
  }, []);

  const stats = useMemo(() => {
    const counts = { safe: 0, warning: 0, harmful: 0, critical: 0 };
    history.forEach((item) => {
      const status = item.status.toLowerCase();
      if (status in counts) {
        counts[status as keyof typeof counts] += 1;
      }
    });
    return counts;
  }, [history]);

  const successRate = history.length ? ((stats.safe / history.length) * 100).toFixed(0) : '0';

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Welcome back</p>
        <h2 className="text-3xl font-semibold text-white">DescFlag AI moderation dashboard</h2>
        <p className="max-w-2xl text-slate-400">Manage content checks and review moderation statistics across text, image, and document workflows.</p>
      </header>

      <div className="grid gap-6 xl:grid-cols-3">
        {summaryCard('Total checks', `${history.length}`, 'Recent moderation activity.')}
        {summaryCard('Safe results', `${stats.safe}`, 'Content approved for publishing.')}
        {summaryCard('Safe share', `${successRate}%`, 'Rate of safe results over the latest checks.')}
      </div>

      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-semibold text-white">Recent moderation activity</h3>
            <p className="text-sm text-slate-400">Latest checks stored in backend history.</p>
          </div>
          <ReportExportButton data={history} filename="descflag-history.json" />
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {loading ? (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">Loading history...</div>
          ) : history.length ? (
            history.map((item) => (
              <article key={item.id} className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm text-slate-400">{formatDate(item.created_at)}</p>
                    <h4 className="mt-2 text-lg font-semibold text-white">{item.file_name ?? item.content_type}</h4>
                  </div>
                  <ResultBadge status={item.status as any} />
                </div>
                <p className="mt-4 text-sm text-slate-400">Categories: {item.categories.join(', ') || 'None'}</p>
                <p className="mt-2 text-sm text-slate-200">Risk score: {item.risk_score.toFixed(0)}%</p>
              </article>
            ))
          ) : (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">No moderation results available.</div>
          )}
        </div>
      </section>
    </div>
  );
}
