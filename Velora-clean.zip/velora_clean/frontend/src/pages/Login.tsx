import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { signIn } = useAuth();

  return (
    <div className="mx-auto max-w-md space-y-8 rounded-3xl border border-slate-800 bg-slate-950 p-8 shadow-sm">
      <div className="space-y-3 text-center">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Welcome back</p>
        <h1 className="text-3xl font-semibold text-white">Velora login</h1>
        <p className="text-sm text-slate-400">Sign in to analyze and publish safely on Velora.</p>
      </div>

      <form
        className="space-y-5"
        onSubmit={async (event) => {
          event.preventDefault();
          setError(null);
          setLoading(true);
          try {
            await signIn({ username, password });
            navigate('/');
          } catch (err) {
            setError(err instanceof Error ? err.message : 'Login failed.');
          } finally {
            setLoading(false);
          }
        }}
      >
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-slate-200">Username</label>
          <input
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            className="w-full rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500"
          />
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-semibold text-slate-200">Password</label>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="w-full rounded-3xl border border-slate-800 bg-slate-900 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500"
          />
        </div>

        {error ? <p className="rounded-3xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p> : null}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading ? 'Signing in...' : 'Sign in'}
        </button>
      </form>

      <p className="text-center text-sm text-slate-400">
        New to Velora?{' '}
        <button type="button" className="text-cyan-300 hover:text-white" onClick={() => navigate('/register')}>
          Create account
        </button>
      </p>
    </div>
  );
}
