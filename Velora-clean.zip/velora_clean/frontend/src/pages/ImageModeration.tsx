import { useState } from 'react';
import FileUploader from '@/components/FileUploader';
import { useModeration } from '@/hooks/useModeration';
import ImageModerationCard from '@/components/ImageModerationCard';
import ResultBadge from '@/components/ResultBadge';

export default function ImageModeration() {
  const [file, setFile] = useState<File | null>(null);
  const { result, loading, error, analyze } = useModeration();

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Image moderation</p>
        <h2 className="text-3xl font-semibold text-white">Analyze image content</h2>
        <p className="max-w-2xl text-slate-400">Upload an image and review AI moderation results for visual content.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <FileUploader label="Select image to moderate" accept="image/*" file={file} onChange={setFile} />
          <button
            type="button"
            disabled={!file || loading}
            onClick={() => file && analyze({ text: '', image: file })}
            className="mt-6 inline-flex items-center justify-center rounded-3xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Analyze Image'}
          </button>
          {error ? <p className="mt-4 rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-200">{error}</p> : null}
        </div>

        <aside className="space-y-6">
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Current status</p>
                <h3 className="text-xl font-semibold text-white">{file?.name ?? 'No image selected'}</h3>
              </div>
              <ResultBadge status={(result?.status ?? 'unknown') as any} />
            </div>
            {result ? <ImageModerationCard result={result} fileName={file?.name ?? 'Unknown'} /> : <p className="mt-4 text-sm text-slate-400">Analyze an image to see the moderation summary.</p>}
          </div>
        </aside>
      </div>
    </div>
  );
}
