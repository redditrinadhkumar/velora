import { useEffect, useState } from 'react';
import { getHistory } from '@/api/moderation';
import type { ScanHistoryItem } from '@/types/moderation';
import HistoryTable from '@/components/HistoryTable';
import ReportExportButton from '@/components/ReportExportButton';

export default function History() {
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHistory(100).then(setHistory).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">History</p>
        <h2 className="text-3xl font-semibold text-white">Velora moderation history</h2>
        <p className="max-w-2xl text-slate-400">Review every analyzed post, image, and document in one place.</p>
      </header>

      <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
        <div>
          <h3 className="text-lg font-semibold text-white">Full scan log</h3>
          <p className="text-sm text-slate-400">Loaded from the backend history endpoint.</p>
        </div>
        <ReportExportButton data={history} filename="velora-history-export.json" />
      </div>

      {loading ? (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">Loading history...</div>
      ) : history.length ? (
        <HistoryTable items={history} />
      ) : (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-8 text-slate-400">No history items are available.
        </div>
      )}
    </div>
  );
}
