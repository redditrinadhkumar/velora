import { useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';

export default function Profile() {
  const { user } = useAuth();

  const joinDate = useMemo(() => {
    if (!user) return '—';
    return new Intl.DateTimeFormat('en-US', {
      dateStyle: 'medium',
    }).format(new Date(user.created_at));
  }, [user]);

  return (
    <div className="space-y-8">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.28em] text-cyan-300/80">Profile</p>
        <h2 className="text-3xl font-semibold text-white">Your Velora profile</h2>
        <p className="max-w-2xl text-slate-400">Manage your account and review publishing statistics.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
        <section className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-cyan-500 text-3xl font-bold text-slate-950">{user?.username.slice(0, 2).toUpperCase() ?? 'V'}</div>
            <div>
              <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Velora user</p>
              <h3 className="text-2xl font-semibold text-white">{user?.username ?? 'Guest'}</h3>
            </div>
          </div>

          <div className="mt-6 grid gap-3 text-sm text-slate-300">
            <div className="rounded-3xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-slate-400">Email</p>
              <p className="mt-1 text-white">{user?.email ?? 'Locked'}</p>
            </div>
            <div className="rounded-3xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-slate-400">Member since</p>
              <p className="mt-1 text-white">{joinDate}</p>
            </div>
          </div>
        </section>

        <section className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-white">Community safety</h3>
          <p className="mt-3 text-sm text-slate-400">Velora moderation is active for every post, image, and document you submit.</p>
          <div className="mt-6 grid gap-3">
            <div className="rounded-3xl bg-slate-900 p-4 text-sm text-slate-200">Total posts: 0</div>
            <div className="rounded-3xl bg-slate-900 p-4 text-sm text-slate-200">Safe posts: 0</div>
            <div className="rounded-3xl bg-slate-900 p-4 text-sm text-slate-200">Warning posts: 0</div>
            <div className="rounded-3xl bg-slate-900 p-4 text-sm text-slate-200">Harmful posts: 0</div>
            <div className="rounded-3xl bg-slate-900 p-4 text-sm text-slate-200">Critical posts: 0</div>
          </div>
        </section>
      </div>
    </div>
  );
}
