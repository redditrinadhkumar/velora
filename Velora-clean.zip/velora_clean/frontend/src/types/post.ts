export interface PostFeedResponse {
  id: number;
  user_id: number;
  username: string;
  content: string;
  image_path?: string | null;
  document_path?: string | null;
  moderation_status: string;
  risk_score: number;
  categories: string[];
  created_at: string;
}
