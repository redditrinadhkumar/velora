export type ModerationStatus = 'safe' | 'warning' | 'harmful' | 'critical' | 'error' | 'unknown';

export interface ModerationResult {
  status: ModerationStatus;
  risk_score: number;
  categories: string[];
  reason: string;
  confidence: number;
}

export interface ScanHistoryItem {
  id: number;
  content_type: string;
  file_name?: string | null;
  status: string;
  risk_score: number;
  categories: string[];
  created_at: string;
}
