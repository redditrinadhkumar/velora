import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { fetchCurrentUser, loginUser, registerUser } from '@/api/auth';
import { setAuthToken, clearAuthToken } from '@/api/client';
import type { AuthResponse, LoginRequest, RegisterRequest, User } from '@/types/auth';

interface AuthContextState {
  user: User | null;
  loading: boolean;
  error: string | null;
  signIn: (payload: LoginRequest) => Promise<AuthResponse>;
  signUp: (payload: RegisterRequest) => Promise<AuthResponse>;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextState | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('velora_token');
    if (token) {
      setAuthToken(token);
      fetchCurrentUser()
        .then(setUser)
        .catch(() => {
          clearAuthToken();
          localStorage.removeItem('velora_token');
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  async function signIn(payload: LoginRequest) {
    setError(null);
    const response = await loginUser(payload);
    localStorage.setItem('velora_token', response.token.access_token);
    setAuthToken(response.token.access_token);
    setUser(response.user);
    return response;
  }

  async function signUp(payload: RegisterRequest) {
    setError(null);
    const response = await registerUser(payload);
    localStorage.setItem('velora_token', response.token.access_token);
    setAuthToken(response.token.access_token);
    setUser(response.user);
    return response;
  }

  function signOut() {
    clearAuthToken();
    localStorage.removeItem('velora_token');
    setUser(null);
  }

  const value = useMemo(
    () => ({ user, loading, error, signIn, signUp, signOut }),
    [user, loading, error],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
