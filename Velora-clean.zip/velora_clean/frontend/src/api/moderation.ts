import api from './client';
import type { ModerationResult, ScanHistoryItem } from '@/types/moderation';

export async function getHealth(): Promise<{ status: string }> {
  const response = await api.get('/health');
  return response.data;
}

export async function moderateText(text: string): Promise<ModerationResult> {
  const response = await api.post('/api/moderate/text', { text });
  return response.data;
}

export async function moderateImage(file: File): Promise<ModerationResult> {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post('/api/moderate/image', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
}

export async function moderateDocument(file: File): Promise<ModerationResult> {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post('/api/moderate/document', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
}

export async function getHistory(limit = 100, offset = 0): Promise<ScanHistoryItem[]> {
  const response = await api.get('/api/history', { params: { limit, offset } });
  return response.data;
}

export async function getScanDetail(id: number): Promise<ScanHistoryItem> {
  const response = await api.get(`/api/history/${id}`);
  return response.data;
}
