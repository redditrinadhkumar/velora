import type { AuthResponse, LoginRequest, RegisterRequest, User } from '@/types/auth';
import api from './client';

export async function loginUser(payload: LoginRequest): Promise<AuthResponse> {
  const response = await api.post('/api/auth/login', payload);
  return response.data;
}

export async function registerUser(payload: RegisterRequest): Promise<AuthResponse> {
  const response = await api.post('/api/auth/register', payload);
  return response.data;
}

export async function fetchCurrentUser(): Promise<User> {
  const response = await api.get('/api/auth/me');
  return response.data;
}
