import api from './client';
import type { PostFeedResponse } from '@/types/post';

export interface CreatePostPayload {
  content: string;
  image?: File | null;
  document?: File | null;
}

export async function createPost(payload: CreatePostPayload): Promise<PostFeedResponse> {
  const formData = new FormData();
  formData.append('content', payload.content);
  if (payload.image) {
    formData.append('image', payload.image);
  }
  if (payload.document) {
    formData.append('document', payload.document);
  }

  const response = await api.post('/api/posts', formData);
  return response.data;
}

export async function listPosts(): Promise<PostFeedResponse[]> {
  const response = await api.get('/api/posts');
  return response.data;
}

export async function getPost(postId: number): Promise<PostFeedResponse> {
  const response = await api.get(`/api/posts/${postId}`);
  return response.data;
}
