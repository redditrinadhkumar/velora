import type { ModerationStatus } from '@/types/moderation';

const statusStyles: Record<ModerationStatus, string> = {
  safe: 'bg-emerald-500/15 text-emerald-300',
  warning: 'bg-amber-500/15 text-amber-300',
  harmful: 'bg-orange-500/15 text-orange-300',
  critical: 'bg-red-500/15 text-red-300',
  error: 'bg-slate-700/15 text-slate-200',
  unknown: 'bg-slate-700/15 text-slate-200',
};

interface ResultBadgeProps {
  status: ModerationStatus;
}

export default function ResultBadge({ status }: ResultBadgeProps) {
  return (
    <span className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] ${statusStyles[status]}`}>
      {status}
    </span>
  );
}
