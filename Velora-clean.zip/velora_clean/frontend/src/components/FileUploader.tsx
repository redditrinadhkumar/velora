interface FileUploaderProps {
  label: string;
  accept: string;
  file: File | null;
  onChange: (file: File | null) => void;
}

export default function FileUploader({ label, accept, file, onChange }: FileUploaderProps) {
  return (
    <div className="space-y-2 rounded-3xl border border-slate-800 bg-slate-950 p-4">
      <label className="block text-sm font-medium text-slate-200">{label}</label>
      <input
        type="file"
        accept={accept}
        onChange={(event) => {
          const selectedFile = event.target.files?.[0] ?? null;
          onChange(selectedFile);
        }}
        className="w-full rounded-2xl border border-slate-800 bg-slate-900 px-4 py-3 text-sm text-slate-100 file:mr-4 file:rounded-full file:border-0 file:bg-cyan-500 file:px-4 file:py-2 file:text-slate-950"
      />
      {file ? <p className="text-sm text-slate-400">Selected file: {file.name}</p> : null}
    </div>
  );
}
