interface RiskScoreMeterProps {
  score: number;
}

export default function RiskScoreMeter({ score }: RiskScoreMeterProps) {
  const normalized = Math.min(Math.max(score, 0), 100);
  const color =
    normalized <= 40 ? 'bg-emerald-400' : normalized <= 70 ? 'bg-amber-400' : 'bg-red-400';

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm text-slate-300">
        <span>Risk Score</span>
        <span className="font-semibold text-white">{normalized.toFixed(0)}%</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full bg-slate-800">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${normalized}%` }} />
      </div>
    </div>
  );
}
