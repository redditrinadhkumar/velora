interface ReportExportButtonProps {
  data: unknown;
  filename?: string;
}

export default function ReportExportButton({ data, filename = 'velora-report.json' }: ReportExportButtonProps) {
  return (
    <button
      type="button"
      onClick={() => {
        const content = JSON.stringify(data, null, 2);
        const blob = new Blob([content], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
      }}
      className="inline-flex items-center rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-semibold text-slate-100 transition hover:border-cyan-400 hover:text-cyan-300"
    >
      Export JSON
    </button>
  );
}
