import type { ModerationResult } from '@/types/moderation';
import ResultBadge from './ResultBadge';
import RiskScoreMeter from './RiskScoreMeter';

interface DocumentModerationCardProps {
  result: ModerationResult;
  fileName: string;
}

export default function DocumentModerationCard({ result, fileName }: DocumentModerationCardProps) {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm text-slate-400">Document</p>
          <h2 className="text-lg font-semibold text-white">{fileName}</h2>
        </div>
        <ResultBadge status={result.status} />
      </div>
      <RiskScoreMeter score={result.risk_score} />
      <div className="mt-6 text-sm text-slate-300">
        <p className="text-slate-400">Reason</p>
        <p>{result.reason || 'No details provided.'}</p>
      </div>
    </div>
  );
}
