import type { ScanHistoryItem } from '@/types/moderation';
import { formatDate } from '@/utils/format';
import ResultBadge from './ResultBadge';

interface HistoryTableProps {
  items: ScanHistoryItem[];
}

export default function HistoryTable({ items }: HistoryTableProps) {
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-950 shadow-sm">
      <table className="min-w-full border-collapse text-left text-sm">
        <thead className="bg-slate-900/80 text-slate-400">
          <tr>
            <th className="px-4 py-4">Time</th>
            <th className="px-4 py-4">Content</th>
            <th className="px-4 py-4">Status</th>
            <th className="px-4 py-4">Risk</th>
            <th className="px-4 py-4">Categories</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} className="border-t border-slate-800 hover:bg-slate-900/70">
              <td className="px-4 py-4 text-slate-400">{formatDate(item.created_at)}</td>
              <td className="px-4 py-4 text-slate-200">{item.file_name ?? item.content_type}</td>
              <td className="px-4 py-4">
                <ResultBadge status={item.status as any} />
              </td>
              <td className="px-4 py-4 text-slate-200">{item.risk_score.toFixed(0)}%</td>
              <td className="px-4 py-4 text-slate-200">{item.categories.join(', ') || 'None'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
