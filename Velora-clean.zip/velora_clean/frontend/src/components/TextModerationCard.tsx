import type { ModerationResult } from '@/types/moderation';
import ResultBadge from './ResultBadge';
import RiskScoreMeter from './RiskScoreMeter';

interface TextModerationCardProps {
  result: ModerationResult;
}

export default function TextModerationCard({ result }: TextModerationCardProps) {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-4">
        <h2 className="text-lg font-semibold text-white">Moderation result</h2>
        <ResultBadge status={result.status} />
      </div>
      <RiskScoreMeter score={result.risk_score} />
      <div className="mt-6 space-y-3 text-sm text-slate-300">
        <div>
          <p className="text-slate-400">Categories</p>
          <p>{result.categories.length ? result.categories.join(', ') : 'None detected'}</p>
        </div>
        <div>
          <p className="text-slate-400">Reason</p>
          <p>{result.reason || 'No details provided.'}</p>
        </div>
        <div>
          <p className="text-slate-400">Confidence</p>
          <p>{(result.confidence * 100).toFixed(0)}%</p>
        </div>
      </div>
    </div>
  );
}
